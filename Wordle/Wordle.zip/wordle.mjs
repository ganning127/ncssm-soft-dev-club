// Import the libraries we need
import fs from 'fs'; // Used for reading and writing files
import chalk from 'chalk'; // Used for coloring our text output
import promptSync from 'prompt-sync'; // Used for getting user input synchronously
const prompt = promptSync(); // Initalize the prompt-sync library

const wordLength = 5; // The length of the words that will be used in our puzzle
const numGuesses = 5; // The number of guesses the player gets to solve the puzzle

const file = fs.readFileSync('words.txt', 'utf8'); // Open the file
const words = file.split('\n').map(word => word.trim()); // Split the file's lines into an array and trim each line for whitespace

const puzzleAnswer = words[Math.floor(Math.random() * words.length)]; // Pick a random word from the words array to be the answer to the puzzle
console.log('Debug, puzzleAnswer:', puzzleAnswer); // Print the puzzle answer for debugging/testing purposes

const guesses = []; // Create a list to hold the player's guesses

// loop a certain number of times to let the player guess a certain number of times
for (let i = 0; i < numGuesses; i++) {
    const guess = prompt( 'Guess a word: ' ).trim(); // Get the player's guess and trim it for whitespace

    // Make sure the player's guess is the correct length
    if (guess.length !== wordLength) { 
        console.log('Guess must be 5 letters long.', '\n'); // If not, inform the player
        i--; // Decrement the index to give the player another guess
        continue; // Skip the rest of the loop
    }

    // Make sure the player's guess is included in our list of words
    if (!words.includes(guess)) { 
        console.log('Guessed word is not included in the game\'s word list!', '\n'); // If not, inform the player
        i--; // Decrement the index to give the player another guess
        continue; // Skip the rest of the loop
    }

    guesses.push(guess); // Add the player's guess to our list of guesses

    console.log('Your Wordle:'); // Print a header for the state of the player's current wordle
    // Grade and print each of the player's guesses
    guesses.forEach(guess => {  
        let grading = ''; // Create a string to hold the player's guess's grading

        // Loop through each letter in the player's guess
        for (let j = 0; j < 5; j++) {
            // Append a green letter to the grading if the letter is the same letter in the same position as the answer
            if (guess[j] === puzzleAnswer[j]) {
                grading += chalk.green(guess[j]);
            }
            // Append a yellow letter to the grading if the letter is in the answer but not in the same position
            else if (puzzleAnswer.includes(guess[j])) {
                grading += chalk.yellow(guess[j]);
            } 
            // Append a default colored letter to the grading if the letter is not in the answer
            else {
               grading += guess[j];
            }
        }
        console.log(grading); // Print the player's guess's grading
    });
    console.log(); // Print a blank line for formatting

    // Check if the player's guess is the answer
    if (guess === puzzleAnswer) {
        console.log('You win!'); // If so, inform the player
        break; // Break out of the loop to end the game
    }
}

