const express = require('express'); // allows for the server to run
const database = require("@replit/database"); // replits built in key value pair database
const path = require('path'); // get the location of the user URL wise and send them where they need to go

const db = new database() // create a database
const app = express(); // intitialize express
app.use(express.urlencoded({ extended: true }));  

app.listen(3000, () => {
  console.log('server started on port 3000');
}); 

app.post('/link', (req,res) => {
  let key = '' + req.body.key;
  let value = '' + req.body.value;

  db.set(key, value)
    .then(() => {
      res.send('/' + key);
    })
})

app.get('/new', (req, res) => {
  res.sendFile(path.join(__dirname + '/new.html'));
});

app.get('/*', (req, res) => {
  let key = '' + req.originalUrl; // extracts the unique value in the * from the url
  key = key.substring(1); // remove the / from the unique URL

  db.get(key).then(value => {
    if (value != null){
      res.redirect(value)
    }
    else {
      res.sendStatus(404)
    }
  });
})